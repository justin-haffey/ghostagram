using System.Security.Cryptography;
using System.Text.Json;

namespace Ghostagram.Graph.Conformance.Composition;

/// <summary>Explicit composition tooling entry point; local previews never claim producer-linked conformance.</summary>
public static class CompositionRunner
{
    public static int Run(IReadOnlyList<string> args)
    {
        try
        {
            var options = new Dictionary<string, string>(StringComparer.Ordinal);
            var local = false;
            for (var index = 0; index < args.Count; index++)
            {
                var name = args[index];
                if (name == "--local-projections")
                {
                    if (local) throw new ArgumentException("Duplicate local mode.");
                    local = true;
                    continue;
                }
                if (name is not ("--profile" or "--output") || ++index >= args.Count || !options.TryAdd(name, args[index]))
                    throw new ArgumentException("Unknown, duplicate or missing composition option.");
            }
            if (!local || !options.TryGetValue("--profile", out var profile) || profile != "composition" ||
                !options.TryGetValue("--output", out var output))
                throw new ArgumentException("Local projection generation requires --profile composition --local-projections --output <fresh-directory>.");
            return RunLocal(output);
        }
        catch (Exception exception) when (exception is ArgumentException or IOException or JsonException or InvalidOperationException)
        {
            Console.Error.WriteLine("Composition tooling failed: " + exception.Message);
            return 2;
        }
    }

    private static int RunLocal(string output)
    {
        var destination = Path.GetFullPath(output);
        if (Directory.Exists(destination) && Directory.EnumerateFileSystemEntries(destination).Any())
            throw new IOException("Local projection output must be a new or empty directory.");
        Directory.CreateDirectory(destination);
        var observations = new List<object>();
        var failed = 0;
        foreach (var test in CompositionConsumerSession.LocalCases(new Dictionary<string, string>()))
        {
            var actual = test.Execute();
            var bytes = actual.Result is null ? null : CompositionConsumerProtocol.SerializeProjection(actual.Result);
            var fileName = bytes is null ? null : test.Manifest.CaseId + ".json";
            if (bytes is not null)
                using (var file = new FileStream(Path.Combine(destination, fileName!), FileMode.CreateNew)) file.Write(bytes);
            observations.Add(new { caseId = test.Manifest.CaseId, operationIdentity = test.Manifest.OperationIdentity,
                actual.Passed, actual.Assertion, actual.LocalObservation, actual.AdmissionOutcome,
                status = actual.Result?.Status.ToString(), fileName,
                sha256 = bytes is null ? null : Convert.ToHexStringLower(SHA256.HashData(bytes)) });
            if (!actual.Passed) failed++;
        }
        using (var index = new FileStream(Path.Combine(destination, "local-projection-index.json"), FileMode.CreateNew))
            JsonSerializer.Serialize(index, new { kind = "local-projection-checks", producerLinkedConformance = false, observations }, CompositionConsumerProtocol.JsonOptions);
        Console.WriteLine($"Local projection checks: {observations.Count - failed}/{observations.Count} passed; producer-linked conformance is separate.");
        return failed == 0 ? 0 : 1;
    }
}
